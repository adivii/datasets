File: PA-expert-annotations.txt
Format for each line in txt file: image_file  expert1_annotation  expert2_annotation  expert3_annotation  majority_voting
